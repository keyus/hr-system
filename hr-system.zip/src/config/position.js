//方便扩展
export default {
    'dashboard': [{
        name: '人力资源管理',
        url: ''
    }, {
        name: '部门信息',
        url: ''
    }],
    'depart': [{
        name: '人力资源管理',
        url: ''
    }, {
        name: '部门信息',
        url: ''
    }],
    'project': [{
        name: '人力资源管理',
        url: ''
    }, {
        name: '项目信息',
        url: ''
    }],
    'member': [{
        name: '人力资源管理',
        url: ''
    }, {
        name: '成员信息',
        url: ''
    }],
    'memberChange': [{
        name: '人力资源管理',
        url: ''
    }, {
        name: '成员变更',
        url: ''
    }],

    'manager': [{
        name: '平台管理',
        url: ''
    }, {
        name: '管理员信息',
        url: ''
    }],

    'loginst': [{
        name: '平台管理',
        url: ''
    }, {
        name: '登陆策略',
        url: ''
    }],

    'log': [{
        name: '平台管理',
        url: ''
    }, {
        name: '系统日志',
        url: ''
    }],
}
