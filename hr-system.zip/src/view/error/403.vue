<template>
    <div class="exception___19n05" style="min-height: 500px; height: 80%;">
        <div class="imgBlock___2g-kj">
            <div class="imgEle___cXgra httperror"></div>
        </div>
        <div class="content___3PvOs"><h1>403</h1>
            <div class="desc___3G5g3">抱歉，你无权访问该页面~可能需要您重新登录!</div>
            <div class="actions___1lAdW">
                <router-link to="/login">
                    <button type="button" class="ant-btn ant-btn-primary"><span>返回登录</span></button>
                </router-link>
            </div>
        </div>
    </div>
</template>



